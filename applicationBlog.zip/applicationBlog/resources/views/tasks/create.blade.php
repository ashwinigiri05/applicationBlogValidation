@extends('layouts.master')

  @section('content')
    <div class="col-sm-8 blog-main">
      <h3>Create Task</h3>
      <hr>

      <form method="POST" action = "/tasks">
          {{ csrf_field() }}

          <div class="field">
            <label for="title">Title:</label>

            <input type="text" class="control{{ $errors->has('title') ? 'is-danger' : '' }}" id="title" name="title" >
          </div>

          <div class="field">
            <label for="description">Description :</label>
            <textarea name="description" id="description" class="control{{ $errors->has('description') ? 'is-danger' : '' }}"></textarea>
          </div>
            
          <button type="submit" class="btn btn-info">Create</button>
           @if ($errors->any())
           
            <div class="notification is-danger">
              <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
                
          @endif
      </form>
    </div>

  @endsection