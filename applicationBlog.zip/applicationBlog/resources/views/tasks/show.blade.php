@extends('layouts.master')

    @section('content')
        <div class="col-sm-8 blog-main">
            <h1>{{ $task->title }}</h1>
            <p class="blog-post-meta">{{ $task->created_at->toFormattedDateString()}}</p>
            {{ $task->description }} 
        <hr>
        @if ($task->details->count())
            <div >
                @foreach ($task->details as $detail)
                <strong>{{ $detail->created_at->diffForHumans()}}:<strong>   
                <ul>
                        <li>{{ $detail->name }}</li>
                        <li>{{ $detail->email}}</li>
                        <li>{{ $detail->comment}}</li>
                </ul>   
                
                @endforeach
            </div>
        @endif
        <hr>
        <div class="box">
            <div class="card-block">
                <form method="POST" action = "/tasks/{{$task->id}}/details " class="box">
                    {{ csrf_field() }}
                        <div class="field">
                            <label for="name">Name:</label>
                            <input type="text" class="control{{ $errors->has('name') ? 'is-danger' : '' }}"id="name" name="name">
                        </div>                  
                        <div class="field">
                            <label for="email">Email:</label>
                            <input type="text" class="control{{ $errors->has('email') ? 'is-danger' : '' }}" id="email" name="email">
                        </div>
                        <div class="field">
                            <label for="comment">Comment:</label>
                            <textarea name="comment" id="comment" class="control{{ $errors->has('comment') ? 'is-danger' : '' }}" ></textarea>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-info">Add Comment</button>
                        @if ($errors->any())
           
                        <div class="notification is-danger">
                          <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                            
                      @endif
  

                </form>        
            </div>
        </div>
        <hr> 
        </div>
    @endsection