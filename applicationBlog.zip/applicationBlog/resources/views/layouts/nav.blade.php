<div class="navbar navbar-dark bg-dark">
  <div class="container">
      <nav class="blog-nav">
        <a class="blog-nav-item active" href="#"> Home</a>
      </nav>
  </div>
</div>