<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/layouts/footer.blade.php */ ?>
<footer class="text-muted">
      <div class="container">
        <p class="float-right">
          <a href="#">Back to top</a>
        </p>
        
        <p>New to Bootstrap? <a href="../../tasks">Visit the homepage</a></p>
      </div>
    </footer>