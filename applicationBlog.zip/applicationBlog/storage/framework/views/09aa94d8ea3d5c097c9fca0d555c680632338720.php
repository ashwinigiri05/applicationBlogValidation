<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/tasks/task.blade.php */ ?>
<div class="blog-task">
<h2 class="blog-task-employee_name">
  
    <a href="/tasks/<?php echo e($task->id); ?>/edit">
    <?php echo e($task->employee_name); ?>

    </a>

</h2>
<p class="blog-post-meta"><?php echo e($task->created_at->toFormattedDateString()); ?></p>

<?php echo e($task->description); ?>

</div>