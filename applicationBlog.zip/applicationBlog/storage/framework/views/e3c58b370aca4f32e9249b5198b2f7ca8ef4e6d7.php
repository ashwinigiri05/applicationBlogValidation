<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/tasks/index.blade.php */ ?>
    <?php $__env->startSection('content'); ?>

    <div>
        <button class="btn btn-primary" type="submit" >new</button>
    </div>
    <hr>
    <div class="col-sm-8 blog-main">
            
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <a href="/tasks/<?php echo e($task->id); ?>">
                <?php echo e($task->title); ?>

            </a>

            <p class="blog-post-meta"><?php echo e($task->created_at->toFormattedDateString()); ?></p>

            <?php echo e($task->description); ?>


            <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>